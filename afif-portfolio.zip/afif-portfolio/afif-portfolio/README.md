# 🚀 Afif Zanuar Ardiansyah — Personal Portfolio

Website personal branding dengan backend Node.js + Express  
yang terhubung ke Vercel melalui GitHub.

---

## 📁 Struktur Folder

```
afif-portfolio/
├── backend/
│   ├── server.js      ← Server Express (jangan diubah)
│   └── data.js        ← ⭐ FILE INI YANG ANDA EDIT untuk update konten
├── frontend/
│   └── public/
│       └── index.html ← Tampilan website
├── package.json
├── vercel.json        ← Konfigurasi deploy Vercel
└── .gitignore
```

---

## ✏️ CARA MENGEDIT KONTEN WEBSITE

Buka file **`backend/data.js`** — semua konten ada di sini:

| Bagian         | Apa yang bisa diedit                          |
|----------------|-----------------------------------------------|
| `profile`      | Nama, IPK, role, deskripsi, statistik         |
| `contact`      | Email, WhatsApp, LinkedIn, GitHub             |
| `hardSkills`   | Daftar skill teknis                           |
| `softSkills`   | Daftar soft skill                             |
| `about`        | Paragraf tentang diri                         |
| `experience`   | Pengalaman kerja / magang                     |
| `projects`     | Proyek (bisa tambah link)                     |
| `achievements` | Prestasi dan organisasi                       |
| `certifications` | Daftar sertifikasi                          |

Setelah edit → simpan → `git push` → website otomatis update!

---

## 🖥️ CARA MENJALANKAN DI LAPTOP (Development)

```bash
# 1. Install dependencies (sekali saja)
npm install

# 2. Jalankan server
npm run dev

# 3. Buka browser ke:
http://localhost:3000
```

---

## 🌐 CARA DEPLOY KE GITHUB + VERCEL

### Langkah 1 — Upload ke GitHub

```bash
# Di folder proyek, buka terminal lalu:
git init
git add .
git commit -m "first commit: portfolio afif"
git branch -M main

# Buat repo baru di github.com (nama: afif-portfolio)
# Lalu sambungkan:
git remote add origin https://github.com/USERNAME/afif-portfolio.git
git push -u origin main
```

### Langkah 2 — Deploy ke Vercel

1. Buka **https://vercel.com** → Login dengan GitHub
2. Klik **"Add New Project"**
3. Pilih repo **afif-portfolio**
4. Klik **Deploy** (biarkan setting default)
5. ✅ Selesai! Website live di `afif-portfolio.vercel.app`

### Langkah 3 — Update Website (setiap kali ada perubahan)

```bash
# Edit data.js → simpan → lalu:
git add .
git commit -m "update: tambah pengalaman baru"
git push
# Vercel otomatis deploy dalam ~30 detik
```

---

## 🌍 DOMAIN SENDIRI (Opsional)

Jika ingin domain seperti `afifzanuar.com`:
1. Beli domain di **Niagahoster** / **Namecheap** (~Rp 150rb/tahun)
2. Di Vercel → Settings → Domains → Add Domain
3. Ikuti instruksi DNS yang diberikan Vercel
4. Selesai! Domain pribadi aktif dalam 1-24 jam

---

## 📞 Butuh bantuan?

Hubungi: yafif222@gmail.com
