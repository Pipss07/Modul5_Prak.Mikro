const express = require('express');
const cors = require('cors');
const path = require('path');
const cvData = require('./data');

const app = express();
const PORT = process.env.PORT || 3000;

// ── MIDDLEWARE ────────────────────────────────────────────────
app.use(cors());
app.use(express.json());

// Sajikan file frontend statis dari folder public
app.use(express.static(path.join(__dirname, '../frontend/public')));

// ── API ROUTES ────────────────────────────────────────────────

// GET semua data CV sekaligus (dipakai frontend)
app.get('/api/cv', (req, res) => {
  res.json({ success: true, data: cvData });
});

// GET per-section (opsional, untuk kebutuhan spesifik)
app.get('/api/cv/profile',         (req, res) => res.json(cvData.profile));
app.get('/api/cv/contact',         (req, res) => res.json(cvData.contact));
app.get('/api/cv/experience',      (req, res) => res.json(cvData.experience));
app.get('/api/cv/projects',        (req, res) => res.json(cvData.projects));
app.get('/api/cv/achievements',    (req, res) => res.json(cvData.achievements));
app.get('/api/cv/certifications',  (req, res) => res.json(cvData.certifications));
app.get('/api/cv/skills',          (req, res) => res.json({
  hard: cvData.hardSkills,
  soft: cvData.softSkills
}));

// POST form kontak → kirim ke email via nodemailer (opsional, aktifkan jika perlu)
app.post('/api/contact', async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ success: false, message: 'Semua field wajib diisi.' });
  }
  // Untuk sekarang cukup log — bisa disambung nodemailer/emailjs nanti
  console.log(`[KONTAK MASUK] Dari: ${name} <${email}> | Pesan: ${message}`);
  res.json({ success: true, message: 'Pesan berhasil diterima! Afif akan segera menghubungi Anda.' });
});

// Semua route lain → kirim index.html (Single Page)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/public/index.html'));
});

// ── START SERVER ─────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅ Server berjalan di http://localhost:${PORT}`);
  console.log(`📡 API tersedia di http://localhost:${PORT}/api/cv`);
});
