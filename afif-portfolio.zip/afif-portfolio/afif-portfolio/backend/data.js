// ============================================================
// FILE INI ADALAH PUSAT DATA CV ANDA
// Edit bagian ini kapan saja untuk memperbarui website Anda
// Setelah edit → git push → Vercel otomatis update
// ============================================================

const cvData = {

  // ── PROFIL UTAMA ──────────────────────────────────────────
  profile: {
    name: "Afif Zanuar Ardiansyah",
    initials: "AZ",
    role: "Automation Engineering Technology",
    tagline: "// Available for opportunities",
    ipk: "3.91",
    university: "Universitas Diponegoro",
    program: "D4 Teknologi Rekayasa Otomasi",
    semester: "6",
    location: "Boja, Kendal — Semarang, Jawa Tengah",
    description: `Mahasiswa D4 Universitas Diponegoro dengan spesialisasi 
      Instrumentasi & Kontrol, IoT, dan Robotika. IPK 3.91/4.00 — 
      menggabungkan kecerdasan teknis dengan kemampuan kepemimpinan nyata.`,
    stats: [
      { value: "5+", label: "Pengalaman Kerja" },
      { value: "6+", label: "Proyek" },
      { value: "128", label: "Anggota" }
    ]
  },

  // ── KONTAK ────────────────────────────────────────────────
  contact: {
    email: "yafif222@gmail.com",
    phone: "088233418829",
    linkedin: "https://www.linkedin.com/in/afifzanuar-ardiansyah-a8a977246",
    linkedinLabel: "linkedin.com/in/afifzanuar-ardiansyah",
    github: "",       // isi jika ada: "https://github.com/username"
    instagram: "",    // isi jika ada
  },

  // ── HARD SKILLS ───────────────────────────────────────────
  hardSkills: [
    "C / Arduino IDE",
    "LabView",
    "PLC Cx-Programmer",
    "Autodesk Eagle",
    "EasyEDA",
    "CtrlX SCADA",
    "Fluidsim Pneumatics",
    "MATLAB / PID"
  ],

  // ── SOFT SKILLS ───────────────────────────────────────────
  softSkills: [
    "Leadership",
    "Problem Solving",
    "Komunikasi",
    "Adaptif",
    "Teamwork",
    "Time Management"
  ],

  // ── TENTANG / ABOUT ───────────────────────────────────────
  about: [
    `Saya adalah mahasiswa semester 6 program studi Teknologi Rekayasa Otomasi (D4) 
    Universitas Diponegoro dengan IPK 3.91/4.00. Passion mendalam pada dunia 
    instrumentasi & kontrol sistem, Internet of Things, dan Robotika.`,
    `Pengalaman mencakup magang sebagai Engineer di sektor industri migas, menjadi 
    asisten praktikum di empat mata kuliah, serta memimpin organisasi mahasiswa 
    dengan 128 anggota aktif sebagai Wakil Ketua Himpunan.`,
    `Latar belakang teknis SMK Mekatronika memberikan fondasi kuat yang terus 
    dikembangkan melalui berbagai proyek nyata dan kolaborasi lintas disiplin.`
  ],

  // ── PENGALAMAN KERJA ──────────────────────────────────────
  experience: [
    {
      date: "JAN 2026",
      role: "Instrumentasi & Kontrol Engineer (Intern)",
      company: "PPSDM MIGAS",
      location: "Cepu, Jawa Tengah",
      points: [
        "Perancangan sistem monitoring & kontrol Boiler TWA berbasis PLC",
        "Artikel ilmiah: Analisis kendali level air boiler menggunakan PID berbasis simulasi MATLAB",
        "Memahami proses produksi kilang minyak mentah hingga produk jadi"
      ]
    },
    {
      date: "AGS – DES 2025",
      role: "Asisten Praktikum Sistem Cerdas & Elektronika Daya",
      company: "Universitas Diponegoro",
      location: "Semarang",
      points: [
        "Pengarahan dan pembimbingan praktikum mahasiswa",
        "Pengawasan quiz, pengecekan laporan, dan evaluasi praktikum"
      ]
    },
    {
      date: "AGS – DES 2024",
      role: "Asisten Praktikum Mesin Listrik & Rangkaian Listrik",
      company: "Universitas Diponegoro",
      location: "Semarang",
      points: [
        "Pengecekan laporan, pengarahan, dan evaluasi praktikum"
      ]
    },
    {
      date: "FEB 2024 – SEKARANG",
      role: "Pengampu Ekstrakulikuler Robotik",
      company: "SMP Islam Hidayatullah",
      location: "Semarang",
      points: [
        "Mengajar pemrograman, elektrikal, dan mekanikal untuk siswa SMP"
      ]
    },
    {
      date: "JUN – NOV 2022",
      role: "Asisten Engineer (Intern)",
      company: "Halia Teknologi Nusantara",
      location: "Bekasi, Jawa Barat",
      points: [
        "Mengerjakan Project Mobile Robotic Trainer Kit",
        "Membuat tutorial Multisim, MyDAQ, MyRIO beserta video tutorialnya",
        "Membuat service report dan Gantt Chart"
      ]
    }
  ],

  // ── PROYEK ────────────────────────────────────────────────
  projects: [
    {
      num: "PROJECT_001",
      title: "Sistem Monitoring & Kontrol Boiler TWA Berbasis PLC",
      desc: "Perancangan sistem kendali level air boiler di PPSDM MIGAS menggunakan metode PID berbasis PLC dengan analisis simulasi MATLAB.",
      tags: ["PLC", "PID Control", "MATLAB"],
      link: ""
    },
    {
      num: "PROJECT_002",
      title: "Fire Alarm Control System (FACP)",
      desc: "Replika sistem kontrol alarm kebakaran yang dirancang dan diimplementasikan di Lab Teaching Factory Elektronika Terpadu Undip.",
      tags: ["FACP", "PCB Design", "Safety System"],
      link: ""
    },
    {
      num: "PROJECT_003",
      title: "Fire Suppression PLN 300 KVA (V1 & V2)",
      desc: "Sistem fire suppression skala industri untuk trafo PLN 300 KVA dalam dua versi iterasi peningkatan performa.",
      tags: ["Fire Suppression", "Industrial", "PLN"],
      link: ""
    },
    {
      num: "PROJECT_004",
      title: "Robot Lawnmower Otonom",
      desc: "Pengembangan robot pemotong rumput otonom sebagai proyek inovasi di Laboratorium TEFA ET Universitas Diponegoro.",
      tags: ["Robotika", "Arduino", "Automation"],
      link: ""
    },
    {
      num: "PROJECT_005",
      title: "Mobile Robotic Trainer Kit",
      desc: "Trainer kit robotik mobile untuk edukasi industri, dikembangkan bersama Halia Teknologi Nusantara untuk ITB dan POLMAN.",
      tags: ["Mobile Robot", "Education Tech"],
      link: ""
    },
    {
      num: "PROJECT_006",
      title: "Modul Praktikum: Fisika Teknik, Mikrokontroler & PIPL",
      desc: "Pengerjaan modul praktikum tiga mata kuliah — Fisika Teknik, Mikrokontroler & Embedded System, dan Panel Instalasi Listrik.",
      tags: ["Embedded System", "PCB", "Panel Listrik"],
      link: ""
    }
  ],

  // ── PRESTASI & ORGANISASI ─────────────────────────────────
  achievements: [
    { icon: "🏆", title: "Finalis ICHEDECE 2024", org: "Indonesia Chemical Reaction Car — HMT Kimia UNS" },
    { icon: "🥈", title: "Juara 2 Lomba Futsal — Saota Fest", org: "HM Akuntansi Perpajakan — Sep 2024" },
    { icon: "🥇", title: "Juara 1 Lomba Futsal — IKAMMI CUP", org: "Ikatan Mahasiswa Minang — Mar 2024" },
    { icon: "👑", title: "Wakil Ketua Himpunan HIMATRO", org: "128 anggota aktif, 11 bidang/biro/unit — Apr 2025" },
    { icon: "🤖", title: "Tim Support KRI Regional & Nasional 2024", org: "URDC — Tim Barracuda, Divisi Programming" },
    { icon: "🔧", title: "Supervisor Line Production — Lab TEFA ET", org: "Divisi Etching — Produksi PCB & Proyek Industri" }
  ],

  // ── SERTIFIKASI ───────────────────────────────────────────
  certifications: [
    { name: "Black Gold Unplugged: A to Z of Oil & Gas Industry", issuer: "PPSDM MIGAS", date: "OKT 2025" },
    { name: "PLC Based Electrical Equipment Operation Cluster", issuer: "Lab TEFA ET — Universitas Diponegoro", date: "OKT 2024" },
    { name: "PCB Manufacture", issuer: "Lab TEFA ET — Universitas Diponegoro", date: "JUL 2024" },
    { name: "LKMMD — Latihan Manajemen Mahasiswa Dasar", issuer: "BEM Psikologi", date: "MEI 2024" },
    { name: "Leadership Training (LT)", issuer: "HIMATRO — Universitas Diponegoro", date: "FEB 2024" },
    { name: "Pneumatic Technician Maintenance System", issuer: "SMK Negeri 7 Semarang", date: "MAR 2023" }
  ]
};

module.exports = cvData;
